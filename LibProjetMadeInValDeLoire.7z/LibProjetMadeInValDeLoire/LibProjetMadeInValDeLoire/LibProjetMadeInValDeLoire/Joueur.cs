﻿namespace LibProjetMadeInValDeLoire
{
    public class Joueur
    {
        #region propriétés/Property

        private String id;
        private String nom;
        private String prenom;
        private DateTime dateNaissance;
        private String login;
        private String motPasse;
        private String section;
        private int score;

        public int Score
        {
            get { return score; }
            set { score = value; }
        }


        public String Section
        {
            get { return section; }
            set { section = value; }
        }


        public String MotPasse
        {
            get { return motPasse; }
            set { motPasse = value; }
        }


        public String Login
        {
            get { return login; }
            set { login = value; }
        }


        public DateTime DateNaissance
        {
            get { return dateNaissance; }
            set { dateNaissance = value; }
        }


        public String Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }


        public String Nom
        {
            get { return nom; }
            set { nom = value; }
        }


        public String Id
        {
            get { return id; }
            set { id = value; }
        }

        #endregion


        #region Procédures
        /* augScore */
        /* rajoute un point au score du joueur */
        public void augScore()
        {
            score += 1;
        }
        #endregion
    }
}