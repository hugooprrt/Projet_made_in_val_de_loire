﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class Resultat
    {
        #region propriétés/Property

        private int numeroQuiz;
        private String idJoueur;
        private DateTime dateObtention;
        private int nbBonneRep;

        public int NbBonneRep
        {
            get { return nbBonneRep; }
            set { nbBonneRep = value; }
        }


        public DateTime DateObtention
        {
            get { return dateObtention; }
            set { dateObtention = value; }
        }


        public String IdJoueur
        {
            get { return idJoueur; }
            set { idJoueur = value; }
        }


        public int NumeroQuiz
        {
            get { return numeroQuiz; }
            set { numeroQuiz = value; }
        }

        #endregion
    }
}
