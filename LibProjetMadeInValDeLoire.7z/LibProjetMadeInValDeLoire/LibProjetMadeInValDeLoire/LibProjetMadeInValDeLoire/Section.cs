﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class Section
    {
        #region propriétés/Property

        private String id;
        private String nom;
        private DateTime annee;
        private String specialite;

        public String Specialite
        {
            get { return specialite; }
            set { specialite = value; }
        }


        public DateTime Annee
        {
            get { return annee; }
            set { annee = value; }
        }


        public String Nom
        {
            get { return nom; }
            set { nom = value; }
        }


        public String Id
        {
            get { return id; }
            set { id = value; }
        }

        #endregion
    }
}
