﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class Question
    {
        #region propriétés/Property

        private int numero;
        private String libelle;
        private String niveauDifficulte;
        private String theme;

        public String Theme
        {
            get { return theme; }
            set { theme = value; }
        }


        public String NiveauDifficulte
        {
            get { return niveauDifficulte; }
            set { niveauDifficulte = value; }
        }


        public String Libelle
        {
            get { return libelle; }
            set { libelle = value; }
        }


        public int Numero
        {
            get { return numero; }
            set { numero = value; }
        }

        #endregion
    }
}
