﻿using Google.Protobuf;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;
using System.Reflection.Emit;
using System.Windows;

namespace LibProjetMadeInValDeLoire
{
    public class connexionBaseDonnee
    {
        #region Propriété / Property
        private String messageBdd;
        private MySqlConnection connexion;

        public MySqlConnection Connexion
        {
            get { return connexion; }
        }


        public String MessageBdd
        {
            get { return messageBdd; }
        }

        #endregion

        #region Constructeur
        /// <summary>
        /// connexionBaseDonnee : Constructeur
        /// </summary>
        /// <param name="connexion"></param>
        public connexionBaseDonnee(MySqlConnection connexion)
        {
            this.connexion = connexion;
            messageBdd = "";
        }
        #endregion
        #region Connexion/Deconnexion BDD
        /// <summary>
        /// Méthode pour ouvrir la connxexion à la base 
        /// </summary>
        public void OuvrirConnexion()
        {
            try
            {
                if (connexion.State == ConnectionState.Closed)
                {
                    connexion.Open();
                    messageBdd = "Connexion à la base de données ouverte avec succès.";
                }
            }
            catch (MySqlException ex)
            {
                messageBdd = "Erreur lors de l'ouverture de la connexion à la base de données : " + ex.Message;
            }
        }
        /// <summary>
        /// Méthode pour fermer la connexion à la base 
        /// </summary>
        public void FermerConnexion()
        {
            try
            {
                if (connexion.State == ConnectionState.Open)
                {
                    connexion.Close();
                    messageBdd = "Connexion à la base de données fermée avec succès.";
                }
            }
            catch (Exception ex)
            {
                messageBdd = "Erreur lors de la fermeture de la connexion à la base de données : " + ex.Message;
            }
        }
        #endregion

    }
}
