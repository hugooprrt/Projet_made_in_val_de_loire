﻿namespace LibProjetMadeInValDeLoire
{
    public class Joueur
    {
        #region propriétés/Property

        private String id;
        private String nom;
        private String prenom;
        private DateTime dateNaissance;
        private String login;
        private String motPasse;
        private String section;
        private int score;

        #region Constructeur 
        /// <summary>
        /// Joueur : Constructeur
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nom"></param>
        /// <param name="prenom"></param>
        /// <param name="dateNaissance"></param>
        /// <param name="login"></param>
        /// <param name="motPasse"></param>
        /// <param name="section">Section du joueur</param>
        /// <param name="score">Score du joueur</param>
        public Joueur(String id, String nom, String prenom, DateTime dateNaissance, String login, String motPasse, String section, int score )
        {
            this.id = id;
            this.nom = nom;
            this.prenom = prenom;
            this.dateNaissance = dateNaissance;
            this.login = login;
            this.motPasse = motPasse;
            this.section = section;
            this.score = score;
        }
        #endregion
        public int Score
        {
            get { return score; }
            set { score = value; }
        }


        public String Section
        {
            get { return section; }
            set { section = value; }
        }


        public String MotPasse
        {
            get { return motPasse; }
            set { motPasse = value; }
        }


        public String Login
        {
            get { return login; }
            set { login = value; }
        }


        public DateTime DateNaissance
        {
            get { return dateNaissance; }
            set { dateNaissance = value; }
        }


        public String Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }


        public String Nom
        {
            get { return nom; }
            set { nom = value; }
        }


        public String Id
        {
            get { return id; }
            set { id = value; }
        }

        #endregion


        #region Procédures
       /// <summary>
       /// méthode augmenter score
       /// </summary>
        public void augScore()
        {
            score += 1;
        }
        #endregion
    }
}