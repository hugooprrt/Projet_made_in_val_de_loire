﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class QuestionsQuiz
    {
        #region propriétés/Property

        private int numeroQuiz;
        private int numeroQuestion;

        public int NumeroQuestion
        {
            get { return numeroQuestion; }
            set { numeroQuestion = value; }
        }


        public int NumeroQuiz
        {
            get { return numeroQuiz; }
            set { numeroQuiz = value; }
        }

        #endregion
    }
}
