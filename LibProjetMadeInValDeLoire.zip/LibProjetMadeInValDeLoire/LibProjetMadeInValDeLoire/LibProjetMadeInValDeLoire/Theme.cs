﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class Theme
    {
        #region propriétés/Property

        private int numero;
        private String libelle;

        #region Constructeur 
        /// <summary>
        /// Theme : Constructeur
        /// </summary>
        /// <param name="numero"></param>
        /// <param name="libelle"></param>
        public Theme(int numero, String libelle)
        {
            this.numero = numero;
            this.libelle = libelle;
        }
        #endregion
        public String Libelle
        {
            get { return libelle; }
            set { libelle = value; }
        }


        public int Numero
        {
            get { return numero; }
            set { numero = value; }
        }

        #endregion
    }
}
