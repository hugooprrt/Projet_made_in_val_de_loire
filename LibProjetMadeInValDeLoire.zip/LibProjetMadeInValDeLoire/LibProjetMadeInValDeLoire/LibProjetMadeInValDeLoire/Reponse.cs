﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class Reponse
    {
        #region propriétés/Property

        private int numero;
        private int numeroProposition;

        public int NumeroProposition
        {
            get { return numeroProposition; }
            set { numeroProposition = value; }
        }


        public int Numero
        {
            get { return numero; }
            set { numero = value; }
        }

        #endregion
    }
}
