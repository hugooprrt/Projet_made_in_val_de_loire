﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class Resultat
    {
        #region propriétés/Property

        private int numeroQuiz;
        private String idJoueur;
        private DateTime dateObtention;
        private int nbBonneRep;

        #region Constructeur 
        /// <summary>
        /// Resultat : Constructeur
        /// </summary>
        /// <param name="numeroQuiz"></param>
        /// <param name="idJoueur"></param>
        /// <param name="dateObtention"></param>
        /// <param name="nbBonneRep"></param>
        public Resultat(int numeroQuiz, String idJoueur, DateTime dateObtention, int nbBonneRep)
        {
            this.numeroQuiz = numeroQuiz;
            this.idJoueur = idJoueur;
            this.dateObtention = dateObtention;
            this.nbBonneRep = nbBonneRep;
        }
        #endregion
        public int NbBonneRep
        {
            get { return nbBonneRep; }
            set { nbBonneRep = value; }
        }


        public DateTime DateObtention
        {
            get { return dateObtention; }
            set { dateObtention = value; }
        }


        public String IdJoueur
        {
            get { return idJoueur; }
            set { idJoueur = value; }
        }


        public int NumeroQuiz
        {
            get { return numeroQuiz; }
            set { numeroQuiz = value; }
        }

        #endregion
    }
}
