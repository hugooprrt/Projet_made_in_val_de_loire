﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class NiveauDifficulte
    {
        #region propriétés/Property

        private String id;
        private String libelle;

        public String Libelle
        {
            get { return libelle; }
            set { libelle = value; }
        }

        public String Id
        {
            get { return id; }
            set { id = value; }
        }

        #endregion
    }
}
