﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class Quiz
    {

        #region Propriétés/Property

        private int numero;
        private String titre;
        private String description;
        private int nombreQestion;
        private String niveauDifficulte;
        private String theme;

        public String Theme
        {
            get { return theme; }
            set { theme = value; }
        }


        public String NiveauDifficulte
        {
            get { return niveauDifficulte; }
            set { niveauDifficulte = value; }
        }


        public int NombreQuestion
        {
            get { return nombreQestion; }
            set { nombreQestion = value; }
        }

        public String Description
        {
            get { return description; }
            set { description = value; }
        }

        public String Titre
        {
            get { return titre; }
            set { titre = value; }
        }


        public int Numero
        {
            get { return numero; }
            set { numero = value; }
        }
        #endregion
    }
}
