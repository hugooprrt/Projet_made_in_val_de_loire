﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class Question
    {
        #region propriétés/Property

        private int numero;
        private String libelle;
        private String niveauDifficulte;
        private String theme;

        #region Constructeur 
        /// <summary>
        /// Question : Constructeur
        /// </summary>
        /// <param name="numero"></param>
        /// <param name="libelle"></param>
        /// <param name="niveauDifficulte"></param>
        /// <param name="theme"></param>
        public Question(int numero, String libelle, String niveauDifficulte, String theme)
        {
            this.numero = numero;
            this.libelle = libelle;
            this.niveauDifficulte = niveauDifficulte;
            this.theme = theme;
        }
        #endregion
        public String Theme
        {
            get { return theme; }
            set { theme = value; }
        }


        public String NiveauDifficulte
        {
            get { return niveauDifficulte; }
            set { niveauDifficulte = value; }
        }


        public String Libelle
        {
            get { return libelle; }
            set { libelle = value; }
        }


        public int Numero
        {
            get { return numero; }
            set { numero = value; }
        }

        #endregion
    }
}
