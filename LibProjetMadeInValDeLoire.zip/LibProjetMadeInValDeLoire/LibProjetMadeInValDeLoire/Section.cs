﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibProjetMadeInValDeLoire
{
    public class Section
    {
        #region propriétés/Property

        private String id;
        private String nom;
        private DateTime annee;
        private String specialite;

        #region Constructeur 
        /// <summary>
        /// Section : Constructeur
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nom"></param>
        /// <param name="annee"></param>
        /// <param name="specialite"></param>
        public Section(String id, String nom, DateTime annee, String specialite)
        {
            this.id = id;
            this.nom = nom;
            this.annee = annee;
            this.specialite = specialite;
        }
        #endregion
        public String Specialite
        {
            get { return specialite; }
            set { specialite = value; }
        }


        public DateTime Annee
        {
            get { return annee; }
            set { annee = value; }
        }


        public String Nom
        {
            get { return nom; }
            set { nom = value; }
        }


        public String Id
        {
            get { return id; }
            set { id = value; }
        }

        #endregion
    }
}
