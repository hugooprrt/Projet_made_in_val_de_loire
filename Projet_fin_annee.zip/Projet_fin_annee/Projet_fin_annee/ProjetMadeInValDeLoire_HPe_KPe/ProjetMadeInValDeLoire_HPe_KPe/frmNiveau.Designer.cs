﻿namespace ProjetMadeInValDeLoire_HPe_KPe
{
    partial class frmNiveau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNiveau = new System.Windows.Forms.Label();
            this.btnCollege = new System.Windows.Forms.Button();
            this.btnLyceen = new System.Windows.Forms.Button();
            this.btnEtudiants = new System.Windows.Forms.Button();
            this.btnProfessionnel = new System.Windows.Forms.Button();
            this.btnRetour = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNiveau
            // 
            this.lblNiveau.AutoSize = true;
            this.lblNiveau.BackColor = System.Drawing.Color.Transparent;
            this.lblNiveau.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNiveau.ForeColor = System.Drawing.Color.White;
            this.lblNiveau.Location = new System.Drawing.Point(12, 26);
            this.lblNiveau.Name = "lblNiveau";
            this.lblNiveau.Size = new System.Drawing.Size(254, 24);
            this.lblNiveau.TabIndex = 0;
            this.lblNiveau.Text = "Sélectionner votre niveau:";
            // 
            // btnCollege
            // 
            this.btnCollege.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnCollege.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCollege.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCollege.Location = new System.Drawing.Point(54, 82);
            this.btnCollege.Name = "btnCollege";
            this.btnCollege.Size = new System.Drawing.Size(325, 47);
            this.btnCollege.TabIndex = 1;
            this.btnCollege.Text = "Collégiens";
            this.btnCollege.UseVisualStyleBackColor = false;
            this.btnCollege.Click += new System.EventHandler(this.btnCollege_Click);
            // 
            // btnLyceen
            // 
            this.btnLyceen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnLyceen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLyceen.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLyceen.Location = new System.Drawing.Point(54, 177);
            this.btnLyceen.Name = "btnLyceen";
            this.btnLyceen.Size = new System.Drawing.Size(325, 47);
            this.btnLyceen.TabIndex = 2;
            this.btnLyceen.Text = "Lycéens";
            this.btnLyceen.UseVisualStyleBackColor = false;
            this.btnLyceen.Click += new System.EventHandler(this.btnLyceen_Click);
            // 
            // btnEtudiants
            // 
            this.btnEtudiants.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnEtudiants.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEtudiants.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEtudiants.Location = new System.Drawing.Point(54, 230);
            this.btnEtudiants.Name = "btnEtudiants";
            this.btnEtudiants.Size = new System.Drawing.Size(325, 47);
            this.btnEtudiants.TabIndex = 3;
            this.btnEtudiants.Text = "Etudiants";
            this.btnEtudiants.UseVisualStyleBackColor = false;
            this.btnEtudiants.Click += new System.EventHandler(this.btnEtudiants_Click);
            // 
            // btnProfessionnel
            // 
            this.btnProfessionnel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnProfessionnel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnProfessionnel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfessionnel.Location = new System.Drawing.Point(54, 308);
            this.btnProfessionnel.Name = "btnProfessionnel";
            this.btnProfessionnel.Size = new System.Drawing.Size(325, 47);
            this.btnProfessionnel.TabIndex = 4;
            this.btnProfessionnel.Text = "Professionnels";
            this.btnProfessionnel.UseVisualStyleBackColor = false;
            this.btnProfessionnel.Click += new System.EventHandler(this.btnProfessionnel_Click);
            // 
            // btnRetour
            // 
            this.btnRetour.BackColor = System.Drawing.Color.Red;
            this.btnRetour.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRetour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetour.ForeColor = System.Drawing.Color.White;
            this.btnRetour.Location = new System.Drawing.Point(12, 412);
            this.btnRetour.Name = "btnRetour";
            this.btnRetour.Size = new System.Drawing.Size(98, 41);
            this.btnRetour.TabIndex = 5;
            this.btnRetour.Text = "Retour";
            this.btnRetour.UseVisualStyleBackColor = false;
            this.btnRetour.Click += new System.EventHandler(this.btnRetour_Click);
            // 
            // frmNiveau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjetMadeInValDeLoire_HPe_KPe.Properties.Resources.fond_niveau;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(397, 465);
            this.Controls.Add(this.btnRetour);
            this.Controls.Add(this.btnProfessionnel);
            this.Controls.Add(this.btnEtudiants);
            this.Controls.Add(this.btnLyceen);
            this.Controls.Add(this.btnCollege);
            this.Controls.Add(this.lblNiveau);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmNiveau";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Niveau";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNiveau;
        private System.Windows.Forms.Button btnCollege;
        private System.Windows.Forms.Button btnLyceen;
        private System.Windows.Forms.Button btnEtudiants;
        private System.Windows.Forms.Button btnProfessionnel;
        private System.Windows.Forms.Button btnRetour;
    }
}