﻿namespace ProjetMadeInValDeLoire_HPe_KPe
{
    partial class frmAccueil
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitre = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.btnConnection = new System.Windows.Forms.Button();
            this.btnQuiz = new System.Windows.Forms.Button();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.lblPseudo = new System.Windows.Forms.Label();
            this.txtBxPseudo = new System.Windows.Forms.TextBox();
            this.lblDescription2 = new System.Windows.Forms.Label();
            this.lstVwScore = new System.Windows.Forms.ListView();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblPseu = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitre
            // 
            this.lblTitre.AutoSize = true;
            this.lblTitre.BackColor = System.Drawing.Color.Transparent;
            this.lblTitre.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitre.ForeColor = System.Drawing.Color.Lime;
            this.lblTitre.Location = new System.Drawing.Point(290, 20);
            this.lblTitre.Name = "lblTitre";
            this.lblTitre.Size = new System.Drawing.Size(240, 55);
            this.lblTitre.TabIndex = 0;
            this.lblTitre.Text = "SecuQuiz";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.BackColor = System.Drawing.Color.Transparent;
            this.lblDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.ForeColor = System.Drawing.Color.White;
            this.lblDescription.Location = new System.Drawing.Point(12, 89);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(254, 20);
            this.lblDescription.TabIndex = 1;
            this.lblDescription.Text = "Bienvenue sur notre application !";
            // 
            // btnConnection
            // 
            this.btnConnection.BackColor = System.Drawing.Color.Gray;
            this.btnConnection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConnection.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnection.ForeColor = System.Drawing.Color.White;
            this.btnConnection.Location = new System.Drawing.Point(658, 20);
            this.btnConnection.Name = "btnConnection";
            this.btnConnection.Size = new System.Drawing.Size(147, 33);
            this.btnConnection.TabIndex = 2;
            this.btnConnection.Text = "Connexion";
            this.btnConnection.UseVisualStyleBackColor = false;
            this.btnConnection.Click += new System.EventHandler(this.btnConnection_Click);
            // 
            // btnQuiz
            // 
            this.btnQuiz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnQuiz.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnQuiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuiz.ForeColor = System.Drawing.Color.Black;
            this.btnQuiz.Location = new System.Drawing.Point(12, 239);
            this.btnQuiz.Name = "btnQuiz";
            this.btnQuiz.Size = new System.Drawing.Size(413, 48);
            this.btnQuiz.TabIndex = 3;
            this.btnQuiz.Text = "Lancer le quiz";
            this.btnQuiz.UseVisualStyleBackColor = false;
            this.btnQuiz.Click += new System.EventHandler(this.btnQuiz_Click);
            // 
            // btnQuitter
            // 
            this.btnQuitter.BackColor = System.Drawing.Color.Red;
            this.btnQuitter.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnQuitter.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitter.ForeColor = System.Drawing.Color.White;
            this.btnQuitter.Location = new System.Drawing.Point(12, 323);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(413, 48);
            this.btnQuitter.TabIndex = 4;
            this.btnQuitter.Text = "Quitter";
            this.btnQuitter.UseVisualStyleBackColor = false;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click);
            // 
            // lblPseudo
            // 
            this.lblPseudo.AutoSize = true;
            this.lblPseudo.BackColor = System.Drawing.Color.Transparent;
            this.lblPseudo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPseudo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblPseudo.Location = new System.Drawing.Point(12, 175);
            this.lblPseudo.Name = "lblPseudo";
            this.lblPseudo.Size = new System.Drawing.Size(74, 20);
            this.lblPseudo.TabIndex = 7;
            this.lblPseudo.Text = "Pseudo:";
            // 
            // txtBxPseudo
            // 
            this.txtBxPseudo.Location = new System.Drawing.Point(112, 177);
            this.txtBxPseudo.Multiline = true;
            this.txtBxPseudo.Name = "txtBxPseudo";
            this.txtBxPseudo.Size = new System.Drawing.Size(201, 20);
            this.txtBxPseudo.TabIndex = 8;
            // 
            // lblDescription2
            // 
            this.lblDescription2.AutoSize = true;
            this.lblDescription2.BackColor = System.Drawing.Color.Transparent;
            this.lblDescription2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription2.ForeColor = System.Drawing.Color.White;
            this.lblDescription2.Location = new System.Drawing.Point(12, 121);
            this.lblDescription2.Name = "lblDescription2";
            this.lblDescription2.Size = new System.Drawing.Size(518, 20);
            this.lblDescription2.TabIndex = 9;
            this.lblDescription2.Text = " Ici nous proposons plusieurs quiz sur la cybersecurité selon les niveaux. ";
            // 
            // lstVwScore
            // 
            this.lstVwScore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lstVwScore.HideSelection = false;
            this.lstVwScore.Location = new System.Drawing.Point(537, 199);
            this.lstVwScore.Name = "lstVwScore";
            this.lstVwScore.Size = new System.Drawing.Size(253, 163);
            this.lstVwScore.TabIndex = 10;
            this.lstVwScore.UseCompatibleStateImageBehavior = false;
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.BackColor = System.Drawing.Color.Transparent;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.Color.Aqua;
            this.lblScore.Location = new System.Drawing.Point(549, 158);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(221, 25);
            this.lblScore.TabIndex = 11;
            this.lblScore.Text = "10 Meilleurs Scores";
            // 
            // lblPseu
            // 
            this.lblPseu.AutoSize = true;
            this.lblPseu.BackColor = System.Drawing.Color.Transparent;
            this.lblPseu.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPseu.ForeColor = System.Drawing.Color.White;
            this.lblPseu.Location = new System.Drawing.Point(91, 208);
            this.lblPseu.Name = "lblPseu";
            this.lblPseu.Size = new System.Drawing.Size(201, 18);
            this.lblPseu.TabIndex = 12;
            this.lblPseu.Text = "Veuillez entrez un pseudo";
            // 
            // frmAccueil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjetMadeInValDeLoire_HPe_KPe.Properties.Resources.fond_accueil;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(817, 452);
            this.Controls.Add(this.lblPseu);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lstVwScore);
            this.Controls.Add(this.lblDescription2);
            this.Controls.Add(this.txtBxPseudo);
            this.Controls.Add(this.lblPseudo);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.btnQuiz);
            this.Controls.Add(this.btnConnection);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblTitre);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAccueil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Accueil";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitre;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Button btnConnection;
        private System.Windows.Forms.Button btnQuiz;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Label lblPseudo;
        private System.Windows.Forms.TextBox txtBxPseudo;
        private System.Windows.Forms.Label lblDescription2;
        private System.Windows.Forms.ListView lstVwScore;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblPseu;
    }
}

