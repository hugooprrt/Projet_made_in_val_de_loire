﻿using LibProjetMadeInValDeLoire;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetMadeInValDeLoire_HPe_KPe
{
    public partial class frmQuiz : Form
    {
        private Joueur unJoueur;
        public frmQuiz(Joueur unJoueur)
        {
            InitializeComponent();
            this.unJoueur = unJoueur;
            lblJoueur.Text = "Bienvenue" + unJoueur.getNom();
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmNiveau fenetre = new frmNiveau(unJoueur);
            fenetre.Closed += (s, args) => this.Close();
            fenetre.Show();
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
