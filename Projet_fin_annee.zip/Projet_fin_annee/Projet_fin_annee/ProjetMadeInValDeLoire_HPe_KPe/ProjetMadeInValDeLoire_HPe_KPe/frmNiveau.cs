﻿using LibProjetMadeInValDeLoire;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetMadeInValDeLoire_HPe_KPe
{
    public partial class frmNiveau : Form
    {
        private Joueur unJoueur;
        public frmNiveau(Joueur unJoueur)
        {
            InitializeComponent();
            this.unJoueur = unJoueur;
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmAccueil fenetre = new frmAccueil();
            fenetre.Closed += (s, args) => this.Close();
            fenetre.Show();
        }

        private void btnCollege_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmQuiz fenetre = new frmQuiz(unJoueur);
            fenetre.Closed += (s, args) => this.Close();
            fenetre.Show();
        }

        private void btnLyceen_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmQuiz fenetre = new frmQuiz(unJoueur);
            fenetre.Closed += (s, args) => this.Close();
            fenetre.Show();
        }

        private void btnEtudiants_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmQuiz fenetre = new frmQuiz(unJoueur);
            fenetre.Closed += (s, args) => this.Close();
            fenetre.Show();
        }

        private void btnProfessionnel_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmQuiz fenetre = new frmQuiz(unJoueur);
            fenetre.Closed += (s, args) => this.Close();
            fenetre.Show();
        }
    }
}
