﻿namespace ProjetMadeInValDeLoire_HPe_KPe
{
    partial class frmQuiz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblQuiz = new System.Windows.Forms.Label();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.btnRep1 = new System.Windows.Forms.Button();
            this.btnRep2 = new System.Windows.Forms.Button();
            this.btnRep3 = new System.Windows.Forms.Button();
            this.btnRep4 = new System.Windows.Forms.Button();
            this.btnRetour = new System.Windows.Forms.Button();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.lblJoueur = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblQuiz
            // 
            this.lblQuiz.AutoSize = true;
            this.lblQuiz.BackColor = System.Drawing.Color.Transparent;
            this.lblQuiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuiz.ForeColor = System.Drawing.Color.Aqua;
            this.lblQuiz.Location = new System.Drawing.Point(313, 9);
            this.lblQuiz.Name = "lblQuiz";
            this.lblQuiz.Size = new System.Drawing.Size(168, 73);
            this.lblQuiz.TabIndex = 0;
            this.lblQuiz.Text = "Quiz";
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.BackColor = System.Drawing.Color.Transparent;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.ForeColor = System.Drawing.Color.White;
            this.lblQuestion.Location = new System.Drawing.Point(196, 146);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(172, 37);
            this.lblQuestion.TabIndex = 2;
            this.lblQuestion.Text = "la question";
            // 
            // btnRep1
            // 
            this.btnRep1.BackColor = System.Drawing.Color.Transparent;
            this.btnRep1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRep1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRep1.ForeColor = System.Drawing.Color.White;
            this.btnRep1.Location = new System.Drawing.Point(160, 247);
            this.btnRep1.Name = "btnRep1";
            this.btnRep1.Size = new System.Drawing.Size(171, 40);
            this.btnRep1.TabIndex = 3;
            this.btnRep1.Text = "réponse 1";
            this.btnRep1.UseVisualStyleBackColor = false;
            // 
            // btnRep2
            // 
            this.btnRep2.BackColor = System.Drawing.Color.Transparent;
            this.btnRep2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRep2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRep2.ForeColor = System.Drawing.Color.White;
            this.btnRep2.Location = new System.Drawing.Point(490, 247);
            this.btnRep2.Name = "btnRep2";
            this.btnRep2.Size = new System.Drawing.Size(160, 40);
            this.btnRep2.TabIndex = 4;
            this.btnRep2.Text = "réponse 2";
            this.btnRep2.UseVisualStyleBackColor = false;
            // 
            // btnRep3
            // 
            this.btnRep3.BackColor = System.Drawing.Color.Transparent;
            this.btnRep3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRep3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRep3.ForeColor = System.Drawing.Color.White;
            this.btnRep3.Location = new System.Drawing.Point(160, 324);
            this.btnRep3.Name = "btnRep3";
            this.btnRep3.Size = new System.Drawing.Size(171, 37);
            this.btnRep3.TabIndex = 5;
            this.btnRep3.Text = "réponse 3";
            this.btnRep3.UseVisualStyleBackColor = false;
            // 
            // btnRep4
            // 
            this.btnRep4.BackColor = System.Drawing.Color.Transparent;
            this.btnRep4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRep4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRep4.ForeColor = System.Drawing.Color.White;
            this.btnRep4.Location = new System.Drawing.Point(490, 327);
            this.btnRep4.Name = "btnRep4";
            this.btnRep4.Size = new System.Drawing.Size(160, 34);
            this.btnRep4.TabIndex = 6;
            this.btnRep4.Text = "réponse 4";
            this.btnRep4.UseVisualStyleBackColor = false;
            // 
            // btnRetour
            // 
            this.btnRetour.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnRetour.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRetour.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetour.Location = new System.Drawing.Point(567, 26);
            this.btnRetour.Name = "btnRetour";
            this.btnRetour.Size = new System.Drawing.Size(99, 44);
            this.btnRetour.TabIndex = 7;
            this.btnRetour.Text = "Retour";
            this.btnRetour.UseVisualStyleBackColor = false;
            this.btnRetour.Click += new System.EventHandler(this.btnRetour_Click);
            // 
            // btnQuitter
            // 
            this.btnQuitter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnQuitter.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnQuitter.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitter.Location = new System.Drawing.Point(689, 26);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(99, 44);
            this.btnQuitter.TabIndex = 8;
            this.btnQuitter.Text = "Quitter";
            this.btnQuitter.UseVisualStyleBackColor = false;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click);
            // 
            // lblJoueur
            // 
            this.lblJoueur.AutoSize = true;
            this.lblJoueur.BackColor = System.Drawing.Color.Transparent;
            this.lblJoueur.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJoueur.ForeColor = System.Drawing.Color.Red;
            this.lblJoueur.Location = new System.Drawing.Point(12, 9);
            this.lblJoueur.Name = "lblJoueur";
            this.lblJoueur.Size = new System.Drawing.Size(85, 18);
            this.lblJoueur.TabIndex = 9;
            this.lblJoueur.Text = "Bienvenue";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.BackColor = System.Drawing.Color.Transparent;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.Color.Lime;
            this.lblScore.Location = new System.Drawing.Point(22, 416);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(152, 18);
            this.lblScore.TabIndex = 10;
            this.lblScore.Text = "Votre score est de ";
            // 
            // frmQuiz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjetMadeInValDeLoire_HPe_KPe.Properties.Resources.fond_quiz;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(804, 460);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lblJoueur);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.btnRetour);
            this.Controls.Add(this.btnRep4);
            this.Controls.Add(this.btnRep3);
            this.Controls.Add(this.btnRep2);
            this.Controls.Add(this.btnRep1);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.lblQuiz);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmQuiz";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SecuQuiz";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuiz;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Button btnRep1;
        private System.Windows.Forms.Button btnRep2;
        private System.Windows.Forms.Button btnRep3;
        private System.Windows.Forms.Button btnRep4;
        private System.Windows.Forms.Button btnRetour;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Label lblJoueur;
        private System.Windows.Forms.Label lblScore;
    }
}