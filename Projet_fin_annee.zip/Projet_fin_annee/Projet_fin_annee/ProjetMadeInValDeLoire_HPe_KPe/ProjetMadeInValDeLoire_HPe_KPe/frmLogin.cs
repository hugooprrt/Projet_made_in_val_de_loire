﻿using LibProjetMadeInValDeLoire;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetMadeInValDeLoire_HPe_KPe
{
    public partial class frmLogin : Form
    {
        private Joueur joueur;
        public frmLogin()
        {
            InitializeComponent();
            lblMdp.Visible = false;
        }

        private void btnValider_Click(object sender, EventArgs e)
        {
            if (txtBxLogin.Text == "adminsio" && txtBxMdp.Text == "Kirikou2209!")
            {
                joueur = new Joueur(txtBxLogin.Text);
                this.Hide();
                frmNiveau fenetre = new frmNiveau(joueur);
                fenetre.Closed += (s, args) => this.Close();
                fenetre.Show();
            }
            else
            {
                lblMdp.Visible = true;
            }
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmAccueil fenetre = new frmAccueil();
            fenetre.Closed += (s, args) => this.Close();
            fenetre.Show();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBxMdp.Checked == true)
            {
                txtBxMdp.PasswordChar = '\0';
                chkBxMdp.Text = "Cacher le mot de passe";
            }
            else
            {
                txtBxMdp.PasswordChar = '*';
                chkBxMdp.Text = "Voir le mot de passe";
            }
        }
    }
}
