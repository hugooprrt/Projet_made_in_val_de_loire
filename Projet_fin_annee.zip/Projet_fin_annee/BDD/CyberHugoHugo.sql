-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mar. 26 sep. 2023 à 10:52
-- Version du serveur :  10.3.34-MariaDB-0+deb10u1
-- Version de PHP : 7.3.31-1~deb10u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `CyberHugoHugo`
--

-- --------------------------------------------------------

--
-- Structure de la table `joueur`
--

CREATE TABLE `joueur` (
  `ID` smallint(6) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(32) NOT NULL,
  `dateNaissance` datetime NOT NULL,
  `mail` varchar(255) NOT NULL,
  `login` varchar(40) NOT NULL,
  `motPasse` varchar(40) NOT NULL,
  `section_` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `niveaudifficulte`
--

CREATE TABLE `niveaudifficulte` (
  `ID` varchar(4) NOT NULL COMMENT 'Identifiant ( F pour Facile, D pour Difficile, E pour Expert)',
  `libelle` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `proposition`
--

CREATE TABLE `proposition` (
  `NUMERO` smallint(6) NOT NULL,
  `libelle` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

CREATE TABLE `question` (
  `NUMERO` smallint(6) NOT NULL,
  `libelle` varchar(40) NOT NULL,
  `niveauDifficulte_` varchar(4) NOT NULL,
  `theme_` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `questionquiz`
--

CREATE TABLE `questionquiz` (
  `NUMEROQUIZ` smallint(6) NOT NULL,
  `NUMEROQUESTION` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `quiz`
--

CREATE TABLE `quiz` (
  `NUMERO` smallint(6) NOT NULL,
  `titre` varchar(20) NOT NULL,
  `description` varchar(40) NOT NULL,
  `dateCreation` datetime NOT NULL,
  `dureeEstimee` time NOT NULL COMMENT 'durée estimé du quiz',
  `nombreQuestions` int(11) NOT NULL,
  `niveauDifficulte_` varchar(4) NOT NULL,
  `theme_` smallint(6) NOT NULL COMMENT 'theme choisi pour le quiz'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

CREATE TABLE `reponse` (
  `numeroQuestion_` smallint(6) NOT NULL,
  `numeroProposition_` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `resultat`
--

CREATE TABLE `resultat` (
  `NUMEROQUIZ` smallint(6) NOT NULL,
  `IDJOUEUR` smallint(6) NOT NULL,
  `DATEOBTENTION` datetime NOT NULL,
  `nbBonneRep` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `section`
--

CREATE TABLE `section` (
  `ID` smallint(6) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `annee` year(4) NOT NULL,
  `specialite` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `theme`
--

CREATE TABLE `theme` (
  `NUMERO` smallint(6) NOT NULL,
  `libelle` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `joueur`
--
ALTER TABLE `joueur`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `section_` (`section_`);

--
-- Index pour la table `niveaudifficulte`
--
ALTER TABLE `niveaudifficulte`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `proposition`
--
ALTER TABLE `proposition`
  ADD PRIMARY KEY (`NUMERO`);

--
-- Index pour la table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`NUMERO`);

--
-- Index pour la table `questionquiz`
--
ALTER TABLE `questionquiz`
  ADD PRIMARY KEY (`NUMEROQUIZ`,`NUMEROQUESTION`),
  ADD KEY `NUMEROQUESTION` (`NUMEROQUESTION`);

--
-- Index pour la table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`NUMERO`),
  ADD KEY `niveauDifficulte_` (`niveauDifficulte_`),
  ADD KEY `theme_` (`theme_`);

--
-- Index pour la table `reponse`
--
ALTER TABLE `reponse`
  ADD PRIMARY KEY (`numeroQuestion_`,`numeroProposition_`),
  ADD KEY `numeroProposition_` (`numeroProposition_`);

--
-- Index pour la table `resultat`
--
ALTER TABLE `resultat`
  ADD PRIMARY KEY (`NUMEROQUIZ`,`IDJOUEUR`,`DATEOBTENTION`),
  ADD KEY `IDJOUEUR` (`IDJOUEUR`);

--
-- Index pour la table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `theme`
--
ALTER TABLE `theme`
  ADD PRIMARY KEY (`NUMERO`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `joueur`
--
ALTER TABLE `joueur`
  MODIFY `ID` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `proposition`
--
ALTER TABLE `proposition`
  MODIFY `NUMERO` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `question`
--
ALTER TABLE `question`
  MODIFY `NUMERO` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `NUMERO` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `section`
--
ALTER TABLE `section`
  MODIFY `ID` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `theme`
--
ALTER TABLE `theme`
  MODIFY `NUMERO` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `joueur`
--
ALTER TABLE `joueur`
  ADD CONSTRAINT `joueur_ibfk_1` FOREIGN KEY (`section_`) REFERENCES `section` (`ID`);

--
-- Contraintes pour la table `questionquiz`
--
ALTER TABLE `questionquiz`
  ADD CONSTRAINT `questionquiz_ibfk_1` FOREIGN KEY (`NUMEROQUIZ`) REFERENCES `quiz` (`NUMERO`),
  ADD CONSTRAINT `questionquiz_ibfk_2` FOREIGN KEY (`NUMEROQUESTION`) REFERENCES `question` (`NUMERO`);

--
-- Contraintes pour la table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`niveauDifficulte_`) REFERENCES `niveaudifficulte` (`ID`),
  ADD CONSTRAINT `quiz_ibfk_2` FOREIGN KEY (`theme_`) REFERENCES `theme` (`NUMERO`);

--
-- Contraintes pour la table `reponse`
--
ALTER TABLE `reponse`
  ADD CONSTRAINT `reponse_ibfk_1` FOREIGN KEY (`numeroQuestion_`) REFERENCES `question` (`NUMERO`),
  ADD CONSTRAINT `reponse_ibfk_2` FOREIGN KEY (`numeroProposition_`) REFERENCES `proposition` (`NUMERO`);

--
-- Contraintes pour la table `resultat`
--
ALTER TABLE `resultat`
  ADD CONSTRAINT `resultat_ibfk_1` FOREIGN KEY (`NUMEROQUIZ`) REFERENCES `quiz` (`NUMERO`),
  ADD CONSTRAINT `resultat_ibfk_2` FOREIGN KEY (`IDJOUEUR`) REFERENCES `joueur` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
